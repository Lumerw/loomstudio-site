loom.studio — brand kit 1.0
=================================

PL
--
Ta paczka to pliki z księgi znaku loom.studio (strona /pl/marka). Używaj ich bez zmian.

logo/       logotyp loom.studio (Haus Bold, krzywe — bez fontu): tusz, papier, biały (SVG),
            tusz i papier (PNG 2400 px, przezroczyste tło); logo na osi 1200 × 630 (SVG, PNG 2400 × 1260).
symbol/     sygnet — kwadrat, koło, trójkąt (SVG, PNG 1024 px) i ikona aplikacji 64 × 64 (SVG, PNG 512 px).
colors/     loom-studio-colors.json (kolory, odcienie, gradienty) i loom-studio-tokens.css (tokeny CSS).
glyphs/     ikony sekcji i trójkąt kierunku (Tri) w stanie spoczynkowym (SVG).
gradients/  postery gradientów 1920 × 1080 (PNG): 7 presetów portfolio + hero-ink jasny / ciemny.
textures/   ziarno — jedyna tekstura marki: kafelek 128 × 128 px, na gradiencie z kryciem 6%.

Zasady w skrócie
- Logo zawsze małymi literami, z kropką: loom.studio. Nie zmieniaj kroju, proporcji ani koloru.
- Pole ochronne: x = wysokość litery „o” (0,47 em) z każdej strony.
- Minimalny rozmiar: 18 px (ekran) / 25 mm (druk). Mniej — użyj sygnetu.
- Jeden kolor na logotyp: tusz #000000 na jasnym tle, papier #E8E6DF na ciemnym.
- Na gradientach: biały na ciemnych, czarny (tusz) na jasnych (sun, blush, paper).
- Kontrast logo i tła co najmniej 3 : 1 (jak dla grafiki). Bez cieni, obrysów, poświat, obrotów i gradientu w literach.
- Kolory podstawowe (czerwony #ED3434, niebieski #4F59DB, żółty #F0CA42) to figury i akcenty, nie tła.
- Krój Haus nie jest częścią paczki — jest licencjonowany.

Logo i znaki loom.studio możesz wykorzystać, żeby pokazać współpracę z nami — bez zmian
i zgodnie z księgą znaku. [DO WERYFIKACJI PRAWNEJ]

EN
--
This package holds the files of the loom.studio brand book (page /en/marka). Use them as they are.

logo/       the loom.studio wordmark (Haus Bold, outlined — no font needed): ink, paper, white (SVG),
            ink and paper (PNG 2400 px, transparent); axis lockup 1200 × 630 (SVG, PNG 2400 × 1260).
symbol/     the symbol — square, circle, triangle (SVG, PNG 1024 px) and the 64 × 64 app icon (SVG, PNG 512 px).
colors/     loom-studio-colors.json (colours, shades, gradients) and loom-studio-tokens.css (CSS tokens).
glyphs/     the section glyphs and the direction triangle (Tri) at rest (SVG).
gradients/  gradient posters 1920 × 1080 (PNG): 7 portfolio presets + hero-ink light / dark.
textures/   the grain — the brand's only texture: a 128 × 128 px tile, over gradients at 6% opacity.

Rules in short
- The wordmark is always lowercase, with the dot: loom.studio. Do not change its typeface, proportions or colour.
- Clear space: x = the height of the "o" (0.47 em) on every side.
- Minimum size: 18 px (screen) / 25 mm (print). Smaller — use the symbol.
- One colour per wordmark: ink #000000 on light, paper #E8E6DF on dark.
- On gradients: white on dark ones, black (ink) on light ones (sun, blush, paper).
- Logo-to-background contrast at least 3 : 1, as for graphics. No shadows, outlines, glows, rotation or gradient letters.
- The primaries (red #ED3434, blue #4F59DB, yellow #F0CA42) are figures and accents, not backgrounds.
- The Haus typeface is not included — it is licensed.

You may use the loom.studio logo and marks to show that you work with us — unchanged and
as described in the brand book. [DO WERYFIKACJI PRAWNEJ]
